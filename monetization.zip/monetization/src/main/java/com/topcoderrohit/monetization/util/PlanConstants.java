package com.topcoderrohit.monetization.util;

public class PlanConstants {
public static final int PLAN_DAILY_LIMIT=10;
public static final int PLAN_MONTHLY_LIMIT=500;
public static final int PLAN_QUATERLY_LIMIT=2000;
public static final int PLAN_YEARLY_LIMIT=10000;
}
